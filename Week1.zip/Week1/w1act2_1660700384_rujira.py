def get_num():
    # รับค่าตัวเลข 5 ค่าและเก็บลงใน list
    num_list = []
    for i in range(5):
        num = float(input("Enter Score : "))
        num_list.append(num)
    return num_list

def calc_avg(num_list):
    # คำนวณผลรวม
    total = sum(num_list)
    # คำนวณค่าเฉลี่ย
    avg = total / len(num_list)
    return avg

def main():
    # เรียกใช้งานฟังก์ชัน get_num เพื่อรับค่า
    numbers = get_num()

    # เรียกใช้งานฟังก์ชัน calc_avg เพื่อคำนวณค่าเฉลี่ย
    average = calc_avg(numbers)

    # แสดงผลลัพธ์
    print("Average Score = %.0f"%average)

if __name__ == "__main__":
    main()
