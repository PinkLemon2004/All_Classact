def get_num():
    # รับค่าตัวเลข 5 ค่า
    numbers = []
    for i in range(5):
        num = int(input("Enter Score : "))
        numbers.append(num)
    return numbers

def calc_avg(nums):
    # คำนวณผลรวม
    total = sum(nums)
    # คำนวณค่าเฉลี่ย
    avg = total / len(nums)
    return avg

def main():
    # เรียกใช้งานฟังก์ชัน get_num เพื่อรับค่า
    numbers = get_num()

    # เรียกใช้งานฟังก์ชัน calc_avg เพื่อคำนวณค่าเฉลี่ย
    average = calc_avg(numbers)

    # แสดงผลลัพธ์
    print("Average Score = %.0f"%average)

if __name__ == "__main__":
    main()
