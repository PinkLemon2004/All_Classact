from tkinter import *

def mainwindow() :
  root = Tk()
  root.title("Week6 : Menu & Frame widget")
  root.geometry('400x400')
  menubar = Menu(root)
  menubar.add_command(label="Menu1",command=loadwd1)
  menubar.add_command(label="Menu2",command=loadwd2)
  menubar.add_command(label="Menu3",command=loadwd3)
  root.configure(bg="pink",menu=menubar)
  root.rowconfigure((0),weight=2)
  root.rowconfigure((1),weight=1)
  root.columnconfigure((0),weight=1)
  return root

def createframe(root) :
  fr1 = Frame(root,bg='#597970')
  fr1.rowconfigure((0,1),weight=1)
  fr1.columnconfigure(0,weight=1)
  fr1.grid(row=0,column=0,sticky='news')

  fr2 = Frame(root,bg='#746D5F')
  fr2.rowconfigure(0,weight=1)
  fr2.columnconfigure((0,1,2),weight=1)
  fr2.grid(row=1,column=0,sticky='news')
  return fr1,fr2

def widgetFrame1(fr2) :
  Button(fr2, text='Button1',command=loadwd1).grid(row=0, column=0,padx=10,pady=10,sticky='news')
  Button(fr2, text='Button2',command=loadwd2).grid(row=0, column=1,padx=10,pady=10, sticky='news')
  Button(fr2, text='Button3',command=loadwd3).grid(row=0, column=2,padx=10,pady=10, sticky='news')
    
def loadwd1() :
  frm = Label(fr1,image=img1,bg='red')
  frm.grid(row=0,column=0 ,sticky='news')
  btn1 = Button(fr1, text='Button1')
  btn1.grid(row=1, column=0,padx=10,pady=10,sticky='news')

def loadwd2() :
  frm = Label(fr1,image=img2,bg='green')
  frm.grid(row=0,column=0 ,sticky='news')
  blankFr = Frame(fr1,bg='pink')
  blankFr.grid(row=1,column=0,columnspan=2,sticky='news')

def loadwd3() :
  frm = Frame(fr1,bg='blue')
  frm.grid(row=0,column=0 ,sticky='news')

root = mainwindow()
img1 = PhotoImage(file='Activity/image/book1.png')
img2 = PhotoImage(file='Activity/image/book2.png')
img3 = PhotoImage(file='Activity/image/book3.png')
icon1 = PhotoImage(file='Activity/image/icon1.png')
fr1,fr2 = createframe(root)
widgetFrame1(fr2)
root.mainloop()

