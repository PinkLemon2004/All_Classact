from tkinter import *
from tkinter import messagebox

def mainwindow() :
    root = Tk()
    root.title("GUI5: Example of Week6")
    root.geometry("600x400")
    root.configure(bg='lightgreen')
    root.rowconfigure((0,2),weight=1)
    root.rowconfigure(1,weight=2)
    root.columnconfigure((0,1),weight=1)
    return(root)

def createframe(root) :
    top = Frame(root,bg='#35589A')
    top.rowconfigure(0,weight=1)
    top.columnconfigure(0,weight=1)
    left = Frame(root,bg='#CDDEFF')
    left.rowconfigure((0,1),weight=1)
    left.columnconfigure((0),weight=1)
    right = Frame(root,bg='#EEF2FF')
    right.rowconfigure((0,1),weight=1)
    right.columnconfigure((0),weight=1)
    bottom = Frame(root,bg='#35589A')
    bottom.rowconfigure(0,weight=1)
    bottom.columnconfigure((0,1),weight=1)
    top.grid(row=0,columnspan=2,sticky='news')
    left.grid(row=1,column=0,sticky='news')
    right.grid(row=1,column=1,sticky='news')
    bottom.grid(row=2,columnspan=2,sticky='news')
    return(root,top,left,right,bottom)


def widgettop(top) : 
    Label(top,text="Even and Bind Widget Button",fg='white',font=("Helvetica", "20"),bg="#35589A").grid()

def widgetbottom(bottom) :
    detailspy = StringVar()
    detailspy.set("Copyright @2024 by CS311 Course")
    detail = Label(bottom,textvariable=detailspy,
    bg='#35589A',font=("Helvetica", "12"),fg='white')
    detail.grid(row=0,columnspan=2,ipady=5,pady=5)
    return(detail,detailspy)

def widgetleft(left) :
    leftspy = StringVar()
    tagleft = Label(left, textvariable=leftspy)
    tagleft.grid(row=0,pady=10)
    btnleft = Button(left,text="LEFTButton",bg='#676FA3',fg='#FFBD35')
    btnleft.grid(row=1,sticky='news',pady=10)
    return(tagleft, leftspy, btnleft)

def widgetright(right) :
    rightspy = StringVar()
    tagright = Label(right, textvariable=rightspy)
    tagright.grid(row=0, pady=10)
    btnright =Button(right,text="RIGHTButton",bg='#676FA3',fg='#FFBD35')
    btnright.grid(row=1, sticky='news', pady=10)
    return(tagright, rightspy, btnright)

def leftclick1(event) :
    tagleft['bg'] = "#FF7272"
    leftspy.set("LEFT BUTTION & LEFT CLICK")
    tagright['bg'] = "#FF7272"
    rightspy.set("Waiting...") 

def rightclick1(event) :
    tagleft['bg'] = "#516BEB"
    leftspy.set("LEFT BUTTON & RIGHT CLICK") 
    tagright['bg'] = "#516BEB"
    
    rightspy.set("Waiting...")
    
def leftclick2(event) :
    tagleft['bg'] = "#FF7272"
    leftspy.set("Waiting...")
    tagright['bg'] = "#FF7272"
    rightspy.set("RIGHT BUTTION & LEFT CLICK") 

def rightclick2(event) :
    tagleft['bg'] = "#516BEB"
    leftspy.set("Waiting...") 
    tagright['bg'] = "#516BEB"
    rightspy.set("RIGHT BUTTION & RIGHT CLICK")

def doubleclick(event) :
    detailspy.set("DOUBLE CLICK") 
    root.quit()    
    
root = mainwindow()
root, top, left, right, bottom = createframe(root)
widgettop(top)
tagleft, leftspy, btnleft = widgetleft(left)
tagright, rightspy, btnright = widgetright(right)
detail, detailspy = widgetbottom(bottom)
btnleft.bind("<Button-1>",leftclick1)
btnleft.bind("<Button-3>",rightclick1)
btnright.bind("<Button-1>",leftclick2)
btnright.bind("<Button-3>",rightclick2)
btnleft.bind("<Double-1>",doubleclick)
root.mainloop()
