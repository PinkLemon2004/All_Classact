from tkinter import *

def mainwindow() :
    root = Tk()
    root.title("Week6 - Widget Binding")
    w = 500
    h = 300
    x = root.winfo_screenwidth()/2 - w/2
    y = root.winfo_screenheight()/2 - h/2
    root.geometry('%dx%d+%d+%d'%(w,h,x,y))
    root.option_add('*font',"Garamond 24 bold")
    root.config(bg='yellow')
    root.columnconfigure((0,1),weight=1)
    root.rowconfigure(0,weight=2)

    return root

def widget(root) :
    hbtn = Button(root,text="Hate", width=10)
    hbtn.grid(row=0,column=0,ipady=20,sticky='news')
    hbtn.bind('<Button-1>',hate_click)
    lbtn = Button(root,text="Love", width=10)
    lbtn.grid(row=0,column=1,ipady=20,sticky='news')
    lbtn.bind('<Button-1>',love_click)
    Label(root,textvariable=v_hate, bg="#9bb7d4").grid(row=1,column=0,sticky="news")
    Label(root,textvariable=v_love, bg="#ffb4b4").grid(row=1,column=1,sticky="news")
    Label(root,textvariable=v_total, bg="gold").grid(row=2,columnspan=2,sticky="news")

def hate_click(e) :
    global hate
    hate += 1
    v_hate.set(hate)
    global total
    total += 1
    v_total.set("Total = %d"%total)
def love_click(e) :
    global love
    love += 1
    v_love.set(love)
    global total
    total += 1
    v_total.set("Total = %d"%total)

hate,love,total = 0,0,0
root = mainwindow()
v_hate,v_love,v_total = IntVar(),IntVar(),StringVar()
widget(root)

root.mainloop()